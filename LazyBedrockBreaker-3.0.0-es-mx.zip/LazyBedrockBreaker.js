﻿// LiteLoader-AIDS automatic generated
/// <reference path="d:\LLSE/dts/helperlib/src/index.d.ts"/> 

// 加载语言文件
let lang = {};
const defaultLang = "zh-cn";

function loadLang(code) {
    const path = `./plugins/LazyBedrockBreaker/${code}.json`;
    try {
        const content = file.readFrom(path);
        return JSON.parse(content);
    } catch (e) {
        logger.error(`语言文件加载失败(${code})：${e}`);
        throw new Error(`无法加载语言文件：${path}`);
    }
}

let langCode = defaultLang;
try {
    const manifestRaw = file.readFrom("./plugins/LazyBedrockBreaker/manifest.json");
    const manifest = JSON.parse(manifestRaw);
    const picked = manifest.language || manifest.lang || defaultLang;
    langCode = String(picked).toLowerCase();
} catch (e) {
    logger.error("manifest 读取失败：" + e);
    throw new Error("无法读取 manifest，终止加载");
}

lang = loadLang(langCode);

/**
 * 简易多语言占位符替换
 * @param {string} key 文本键
 * @param {Object} replacements 需要替换的占位符
 */
function tr(key, replacements = {}) {
    let text = lang[key] || key;
    for (const [keyword, value] of Object.entries(replacements)) {
        text = text.replace(`{${keyword}}`, value);
    }
    return text;
}

// 方块白名单
const whiteList = new Set([
    "minecraft:bedrock"
]);

// 全局功能开关
let funcIsOpen = false;

// 注册命令
mc.listen("onServerStarted", () => {
    const bb = mc.newCommand("bedrockbreak", tr("cmdDesc_bb"), PermType.Any, 0x80, "bb");
    bb.setEnum("statusAction", ["isopen"]);
    bb.setEnum("listAction", ["list"]);
    bb.mandatory("action", ParamType.Enum, "statusAction");
    bb.mandatory("action", ParamType.Enum, "listAction");
    bb.mandatory("isOpen", ParamType.Bool);
    bb.overload(["statusAction", "isOpen"]);
    bb.overload(["listAction"]);
    bb.setCallback((_cmd, ori, out, res) => {
        const player = ori.player;
        if (!player) return out.error(tr("error_unknownPlayer"));
        switch (res.action) {
            case "isopen":
                if (!funcIsOpen) {
                    out.error(tr("error_funcNotOpen"))
                    break;
                }
                if (res.isOpen) {
                    player.addTag("BedrockBreak_Open");
                    out.success(tr("success_funcEnabled"));
                } else {
                    player.removeTag("BedrockBreak_Open");
                    out.success(tr("success_funcDisabled"));
                }
                break;
            case "list":
                out.success(tr("success_whitelistHeader"));
                for (const type of whiteList) {
                    out.success(`- ${type}`);
                }
                break;
        }
    });
    bb.setup();

    const bbmaster = mc.newCommand("bedrockbreakmaster", tr("cmdDesc_bbmaster"), PermType.Any, 0x80, "bbmaster");
    bbmaster.setEnum("statusAction", ["isopen"]);
    bbmaster.setEnum("addAction", ["add"]);
    bbmaster.setEnum("removeAction", ["remove"]);
    bbmaster.setEnum("resetAction", ["reset"]);
    bbmaster.setEnum("listAction", ["list"]);
    bbmaster.mandatory("action", ParamType.Enum, "statusAction");
    bbmaster.mandatory("action", ParamType.Enum, "addAction");
    bbmaster.mandatory("action", ParamType.Enum, "removeAction");
    bbmaster.mandatory("action", ParamType.Enum, "resetAction");
    bbmaster.mandatory("action", ParamType.Enum, "listAction");
    bbmaster.mandatory("isOpen", ParamType.Bool);
    bbmaster.overload(["statusAction", "isOpen"]);
    bbmaster.overload(["addAction"]);
    bbmaster.overload(["removeAction"]);
    bbmaster.overload(["resetAction"]);
    bbmaster.overload(["listAction"]);
    bbmaster.setCallback((_cmd, ori, out, res) => {
        const player = ori.player;
        if (!player) return out.error(tr("error_unknownPlayer"));
        const block = player.getBlockFromViewVector();
        switch (res.action) {
            case "isopen":
                funcIsOpen = res.isOpen;
                const status = funcIsOpen ? tr("status_enabled") : tr("status_disabled");
                out.success(tr("success_globalFuncToggled", { status }));
                logger.warn(tr("log_adminToggled", { player: player.name, status }));
                break;
            case "add":
                if (!block) {
                    out.error(tr("error_aimAtBlock"));
                    break;
                }
                else if (whiteList.has(block.type)) {
                    out.error(tr("error_blockInWhitelist"));
                    break;
                }
                else {
                    whiteList.add(block.type);
                    out.success(tr("success_blockAdded", { block: block.type }));
                    logger.warn(tr("log_blockAdded", { player: player.name, block: block.type }));
                }
                break;
            case "remove":
                if (!block) {
                    out.error(tr("error_aimAtBlock"));
                    break;
                }
                else if (!whiteList.has(block.type)) {
                    out.error(tr("error_blockNotInWhitelist"));
                    break;
                }
                else {
                    whiteList.delete(block.type);
                    out.success(tr("success_blockRemoved", { block: block.type }));
                    logger.warn(tr("log_blockRemoved", { player: player.name, block: block.type }));
                }
                break;
            case "reset":
                whiteList.clear();
                whiteList.add("minecraft:bedrock");
                out.success(tr("success_whitelistReset"));
                logger.warn(tr("log_whitelistReset", { player: player.name }));
                break;
            case "list":
                out.success(tr("success_whitelistHeader"));
                for (const type of whiteList) {
                    out.success(`- ${type}`);
                }
                break;
        }
    });
    bbmaster.setup();
});

// 保存玩家点击的方块坐标类
/** 记录玩家点击的目标方块，供后续放置活塞时使用 */
class Manager{
    constructor() {
        // map: playerXuid -> IntPos
        this.map = new Map();
    }

    add(playerXuid, blockPos) {
        this.map.set(playerXuid, blockPos);
        return this;
    }

    get(playerXuid) {
        return this.map.get(playerXuid);
    }

    has(playerXuid) {
        return this.map.has(playerXuid);
    }

    clear() {
        this.map.clear();
        return this;
    }
}
const manager = new Manager();

// 异步任务管理系统类
/** 简单的任务队列：每 tick 执行限定数量的任务 */
class TaskManager {
    constructor() {
        this.tasks = new Array();
    }

    add(task) {
        this.tasks.push(task);
        return this;
    }

    run() {
        if (!this.tasks.length) return;
        const MAX_PER_TICK = 50;
        for (let i = 0; i < MAX_PER_TICK && this.tasks.length; i++) {
            const task = this.tasks.shift();
            try {
                if (!task.execute()) this.tasks.push(task);
            } catch (error) {
                logger.error(tr("error_taskExecute", { error }));
            }
        }
    }
}
const taskManager = new TaskManager();

// 异步等待伸出任务类
const Max_Wait_Time = 4; // 4gt不伸出则补一个红石块 
class ExtendTask {
    constructor(createTime, playerXuid, blockPos, targetPos) {
        this.createTime = createTime;
        this.playerXuid = playerXuid;
        this.blockPos = blockPos;
        this.targetPos = targetPos;
    }

    /**
     * 等待活塞伸出并对准目标方位；超时则补红石块
     * @returns {boolean} true 表示任务完成
     */
    execute() {
        const blockPos = this.blockPos;
        const block = mc.getBlock(blockPos);

        // 块不存在直接结束
        if (!block) return true;

        // 超时处理
        const time = mc.getTime(1);
        if (time > this.createTime + Max_Wait_Time) {
            const RSblock = tryPlaceRSBlock(this.playerXuid, blockPos);
            if (!RSblock) {
                // 放置失败, 终止逻辑
                clearRSBlocksAround(this.playerXuid, blockPos);
                taskManager.add(new RetractTask(this.playerXuid, this.blockPos));
                return true;
            }
            else {
                this.createTime = time;
                return false;
            }
        }

        const dirIndex = block.getBlockState().facing_direction;
        const dir = direction[dirIndex];
        const armPos = getAdjacentPos(blockPos, dir);
        const armBlock = mc.getBlock(armPos);
        if (armBlock && armBlock.type === `${block.type}_arm_collision` &&
            armBlock.getBlockState().facing_direction === dirIndex
        ) {
            // 执行setblock逻辑
            const targetPos = this.targetPos;
            const dirIdx = getDirectionIndexToTarget(blockPos, targetPos);
            if (dirIdx !== -1) mc.setBlock(blockPos, block.type, dirIdx);
            
            // 清除周围的红石块
            clearRSBlocksAround(this.playerXuid, blockPos);

            // 添加收回任务
            taskManager.add(new RetractTask(this.playerXuid, this.blockPos));
            return true;
        }
        else {
            return false;
        }
    }
}

// 异步等待收回任务类
class RetractTask {
    constructor(playerXuid, blockPos) {
        this.playerXuid = playerXuid;
        this.blockPos = blockPos;
    }

    /**
     * 等待活塞前方变为空气后破坏活塞
     * @returns {boolean} true 表示任务完成
     */
    execute() {
        const blockPos = this.blockPos;
        const block = mc.getBlock(blockPos);

        // 块不存在则认为已完成
        if (!block) return true;
        const dir = direction[block.getBlockState().facing_direction];
        const targetPos = getAdjacentPos(blockPos, dir);
        const targetBlock = mc.getBlock(targetPos);
        if (targetBlock && targetBlock.type === "minecraft:air") {
            const player = mc.getPlayer(this.playerXuid);
            const isCreative = player ? player.isCreative : false;
            block.destroy(!isCreative);
            return true;
        }
        else{
            return false;
        }
    }
}

// 活塞朝向与方向对照
const direction = [
    { dx: 0, dy: -1, dz: 0 },   // down 0
    { dx: 0, dy: 1, dz: 0 },    // up 1
    { dx: 0, dy: 0, dz: 1 },    // south 2
    { dx: 0, dy: 0, dz: -1 },   // north 3
    { dx: 1, dy: 0, dz: 0 },    // east 4
    { dx: -1, dy: 0, dz: 0 }    // west 5
];

/**
 * 根据方向索引获取邻近方块坐标
 * @param {IntPos} blockPos 基准位置
 * @param {Object} dir 方向向量对象 {dx,dy,dz}
 */
function getAdjacentPos(blockPos, dir) {
    return new IntPos(
        blockPos.x + dir.dx,
        blockPos.y + dir.dy,
        blockPos.z + dir.dz,
        blockPos.dimid
    );
}

/**
 * 检查功能开关与玩家 tag 权限
 * @param {Player} player 目标玩家
 */
function basicCanUse(player) {
    return funcIsOpen && player && player.hasTag && player.hasTag("BedrockBreak_Open");
}

/**
 * 由基准坐标计算目标在六个方向中的索引
 * @param {IntPos} basePos 基准
 * @param {IntPos} targetPos 目标
 * @returns {number} 方向索引或 -1
 */
function getDirectionIndexToTarget(basePos, targetPos) {
    for (let i = 0; i < 6; i++) {
        const p = getAdjacentPos(basePos, direction[i]);
        if (p.x === targetPos.x && p.y === targetPos.y && p.z === targetPos.z) return i;
    }
    return -1;
}

// 监听玩家右键, 保存玩家点击的方块坐标
mc.listen("onUseItemOn", (player, item, block, _side, _pos) => {
    // 一些基础的逻辑判断
    const itemType = item.type;
    if (!basicCanUse(player) || !whiteList.has(block.type) ||
        (itemType !== "minecraft:piston" && itemType !== "minecraft:sticky_piston")) {
        return;
    }
    manager.add(player.xuid, block.pos);
});

// 监听方块放置
mc.listen("afterPlaceBlock", (player, block) => {
    // 一些基础的逻辑判断
    const blockType = block.type;
    if (!basicCanUse(player) || (blockType !== "minecraft:piston" && blockType !== "minecraft:sticky_piston") || !manager.has(player.xuid)) {
        return;
    }

    // 先找到可以伸出活塞的方向并设置朝向
    const blockPos = block.pos;
    let firstAir = null;
    for (let i = 0; i < 6; i++) {
        const pos = getAdjacentPos(blockPos, direction[i]);
        const neighbor = mc.getBlock(pos);
        if (neighbor && neighbor.type === "minecraft:air") {
            firstAir = { pos, dirIndex: i };
            break;
        }
    }
    if (firstAir) mc.setBlock(blockPos, blockType, firstAir.dirIndex);

    // 检查或尝试获得红石块支撑
    let foundRSblock = false;
    for (let i = 0; i < 6; i++) {
        const target = mc.getBlock(getAdjacentPos(blockPos, direction[i]));
        if (target && target.type === "minecraft:redstone_block") {
            foundRSblock = true;
            break;
        }
    }
    if (!foundRSblock && !tryPlaceRSBlock(player.xuid, blockPos)) return;

    // 添加异步等待伸出任务
    const time = mc.getTime(1);
    taskManager.add(new ExtendTask(time, player.xuid, blockPos, manager.get(player.xuid)));

});

mc.listen("onTick", () => {
    manager.clear();
    taskManager.run();
});

// 尝试放置红石块
function tryPlaceRSBlock(playerXuid, blockPos) {
    // 若玩家无红石块且非创造，直接失败
    const player = mc.getPlayer(playerXuid);
    if (!player) return null;
    const inv = player.getInventory().getAllItems();
    const hasRSblock = player.isCreative || inv.some((item) => item.type === "minecraft:redstone_block");
    if (!hasRSblock) return null;

    const piston = mc.getBlock(blockPos);
    if (!piston) return null;

    // 避免红石块放到活塞臂上
    const dirIndex = piston.getBlockState().facing_direction;
    // 现在开始放置红石块（跳过活塞臂方向）
    for (let i = 0; i < 6; i++) {
        if (i === dirIndex) continue;
        const targetPos = getAdjacentPos(blockPos, direction[i]);
        const target = mc.getBlock(targetPos);
        if (target && target.type === "minecraft:air") {
                mc.setBlock(targetPos, "minecraft:redstone_block");
                if (!player.isCreative) player.clearItem("minecraft:redstone_block", 1);
                return mc.getBlock(targetPos);
        }
    }
    return null;
}

function clearRSBlocksAround(playerXuid, blockPos) {
    // 清理活塞周围辅助放置的红石块
    const player = mc.getPlayer(playerXuid);
    const isCreative = player ? player.isCreative : false;
    for (let i = 0; i < 6; i++) {
        const RSblockPos = getAdjacentPos(blockPos, direction[i]);
        const RSblock = mc.getBlock(RSblockPos);
        if (RSblock && RSblock.type === "minecraft:redstone_block") {
            RSblock.destroy(!isCreative);
        }
    }
}