﻿// LiteLoader-AIDS automatic generated
/// <reference path="d:\LLSE/dts/helperlib/src/index.d.ts"/>

// 定义白名单中的方块类型
const whiteList = new Set([
    "minecraft:bedrock"
]);

// 全局是否开启
let funcIsOpen = false;

//定义所有可能的方向及其对应的坐标偏移
const directions = [
    { facing: 2, dx: 0, dz: 1 },
    { facing: 3, dx: 0, dz: -1 },
    { facing: 4, dx: 1, dz: 0 },
    { facing: 5, dx: -1, dz: 0 }
];

mc.listen("onServerStarted", () => {
    const bb = mc.newCommand("bedrockbreak", "基于CoralFans的懒狗破基岩", PermType.Any, 0x80, "bb");
    bb.setEnum("statusAction", ["isopen"]);
    bb.setEnum("listAction", ["list"]);
    bb.mandatory("action", ParamType.Enum, "statusAction");
    bb.mandatory("action", ParamType.Enum, "listAction");
    bb.mandatory("isOpen", ParamType.Bool);
    bb.overload(["statusAction", "isOpen"]);
    bb.overload(["listAction"]);
    bb.setCallback((_cmd, ori, out, res) => {
        const pl = ori.player;
        if (!pl) return out.error("未知的玩家！");
        switch (res.action) {
            case "isopen":
                if (!funcIsOpen) {
                    out.error("懒狗破基岩未开启！")
                    break;
                }
                if (res.isOpen) {
                    pl.addTag("BedrockBreak_Open");
                    out.success("已开启懒狗破基岩功能！");
                } else {
                    pl.removeTag("BedrockBreak_Open");
                    out.success("已关闭懒狗破基岩功能！");
                }
                break;
            case "list":
                if (whiteList.size === 0) {
                    out.success("白名单为空！");
                }
                else {
                    out.success("白名单中的方块类型有：");
                    for (const type of whiteList) {
                        out.success(`- ${type}`);
                    }
                }
                break;
        }
    });
    bb.setup();

    const bbm = mc.newCommand("bedrockbreakgamemaster", "配置懒狗破基岩", PermType.GameMasters, 0x80, "bbmaster");
    bbm.setEnum("statusAction", ["isopen"]);
    bbm.setEnum("addAction", ["add"]);
    bbm.setEnum("removeAction", ["remove"]);
    bbm.setEnum("listAction", ["list"]);
    bbm.mandatory("action", ParamType.Enum, "statusAction");
    bbm.mandatory("action", ParamType.Enum, "addAction");
    bbm.mandatory("action", ParamType.Enum, "removeAction");
    bbm.mandatory("action", ParamType.Enum, "listAction");
    bbm.mandatory("isOpen", ParamType.Bool);
    bbm.overload(["statusAction", "isOpen"]);
    bbm.overload(["addAction"]);
    bbm.overload(["removeAction"]);
    bbm.overload(["listAction"]);
    bbm.setCallback((_cmd, ori, out, res) => {
        const pl = ori.player;
        if (!pl) return out.error("未知的玩家！");
        switch (res.action) {
            case "isopen":
                if (res.isOpen) {
                    funcIsOpen = true;
                    out.success("已开启全局懒狗破基岩功能！");
                } else {
                    funcIsOpen = false;
                    out.success("已关闭全局懒狗破基岩功能！");
                }
                break;
            case "add":
                const ablock = pl.getBlockFromViewVector();
                if (!ablock) {
                    out.error("未对准任何方块！");
                    break;
                }
                const type = ablock.type;
                if (whiteList.has(type)) {
                    out.error("该方块已在白名单中！");
                }
                else {
                    whiteList.add(type);
                    out.success(`已将${type}添加到白名单中！`);
                }
                break;
            case "remove":
                const rblock = pl.getBlockFromViewVector();
                if (!rblock) {
                    out.error("未对准任何方块！");
                    break;
                }
                const rtype = rblock.type;
                if (!whiteList.has(rtype)) {
                    out.error("该方块不在白名单中！");
                }
                else {
                    whiteList.delete(rtype);
                    out.success(`已将${rtype}从白名单中移除！`);
                }
                break;
            case "list":
                if (whiteList.size === 0) {
                    out.success("白名单为空！");
                }
                else {
                    out.success("白名单中的方块类型有：");
                    for (const type of whiteList) {
                        out.success(`- ${type}`);
                    }
                }
                break;
        }
    });

    bbm.setup();
    return true;
});

mc.listen("afterPlaceBlock", (pl, bl) => {
    //基础逻辑判断
    if (!funcIsOpen) return true; //全局未开启
    if (!pl.hasTag("BedrockBreak_Open")) return true;
    if (bl.type !== "minecraft:piston" && bl.type !== "minecraft:sticky_piston") return true;
    if (!whiteList.has(mc.getBlock(bl.pos.x, bl.pos.y - 1, bl.pos.z, bl.pos.dimid).type)) return true;
    const inv = pl.getInventory().getAllItems();
    let hasRedstoneBlock = false;
    if (!pl.isCreative) {
        for (const it of inv) {
            if (it.id === 152) {
                hasRedstoneBlock = true;
                break;
            }
        }
        if (!hasRedstoneBlock) return true;
    }

    //转到可行方向
    const dx = pl.pos.x - bl.pos.x;
    const dz = pl.pos.z - bl.pos.z;
    const targetDirection = getPistonDirection(dx, dz, bl);
    if (targetDirection === null) return true;
    const currentDirection = bl.getBlockState().facing_direction;
    if (currentDirection !== targetDirection) {
        mc.setBlock(bl.pos, bl.type, targetDirection);
    }    

    //首先检查有没有红石块
    let hasRedstone = false;
    for (const dir of directions) {
        const targetX = bl.pos.x + dir.dx;
        const targetY = bl.pos.y;
        const targetZ = bl.pos.z + dir.dz;
        if (mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid).id === 152) {
            var rsbl = mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid);
            hasRedstone = true;
        }
    }

    //尝试放置红石块
    if (!hasRedstone) {
        var rsbl = placeRedstoneBlock(bl, targetDirection, dx, dz);
        if (rsbl === null) return true;
        if (!pl.isCreative) pl.clearItem("minecraft:redstone_block", 1);
    }

    //尝试破基岩
    setTimeout(() => {
        //转到朝下方向
        for (let i = targetDirection; i < 6; i++) {
            pl.runcmd("rotate");
        }
        rsbl.destroy(!pl.isCreative);
        setTimeout(() => {
            bl.destroy(!pl.isCreative);
        }, 160);
    }, 160);
});

function getPistonDirection(dx, dz, block) {
    //排除朝向玩家的方向和空气
    let validDirections = directions.filter(dir => {
        if (dx > 0 && dir.dx > 0) return false;
        if (dx < 0 && dir.dx < 0) return false;
        if (dz > 0 && dir.dz > 0) return false;
        if (dz < 0 && dir.dz < 0) return false;
        return true;
    });

    //优先选择与玩家方向垂直的方向
    validDirections.sort((a, b) => {
        const aScore = Math.abs(a.dx * dx + a.dz * dz);
        const bScore = Math.abs(b.dx * dx + b.dz * dz);
        return aScore - bScore;
    });

    //检查每个有效方向的目标位置是否为空气
    for (const dir of validDirections) {
        const targetX = block.pos.x + dir.dx;
        const targetY = block.pos.y;
        const targetZ = block.pos.z + dir.dz;
        if (mc.getBlock(targetX, targetY, targetZ, block.pos.dimid).id === 0) {
            return dir.facing;
        }
    }

    //只排除空气
    for (const dir of directions) {
        const targetX = block.pos.x + dir.dx;
        const targetY = block.pos.y;
        const targetZ = block.pos.z + dir.dz;
        if (mc.getBlock(targetX, targetY, targetZ, block.pos.dimid).id === 0) {
            return dir.facing;
        }
    }
    return null;
}

function placeRedstoneBlock(bl, pistonFacing, dx, dz) {
    //排除活塞朝向和玩家方向和空气
    let validDirections = directions.filter(dir => {
        if (dir.facing === pistonFacing) return false;
        if (dx > 0 && dir.dx > 0) return false;
        if (dx < 0 && dir.dx < 0) return false;
        if (dz > 0 && dir.dz > 0) return false;
        if (dz < 0 && dir.dz < 0) return false;
        return true;
    });

    //优先选择与玩家方向垂直的方向
    validDirections.sort((a, b) => {
        const aScore = Math.abs(a.dx * dx + a.dz * dz);
        const bScore = Math.abs(b.dx * dx + b.dz * dz);
        return aScore - bScore;
    });

    //检查每个有效方向的位置是否为空气
    for (const dir of validDirections) {
        const targetX = bl.pos.x + dir.dx;
        const targetY = bl.pos.y;
        const targetZ = bl.pos.z + dir.dz;
        if (mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid).id === 0) {
            mc.setBlock(targetX, targetY, targetZ, bl.pos.dimid, "minecraft:redstone_block", 0);
            return mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid);
        }
    }

    //只排除活塞朝向方向和空气
    validDirections = directions.filter(dir => dir.facing !== pistonFacing);

    //检查每个有效方向的位置是否为空气
    for (const dir of validDirections) {
        const targetX = bl.pos.x + dir.dx;
        const targetY = bl.pos.y;
        const targetZ = bl.pos.z + dir.dz;
        if (mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid).id === 0) {
            mc.setBlock(targetX, targetY, targetZ, bl.pos.dimid, "minecraft:redstone_block", 0);
            return mc.getBlock(targetX, targetY, targetZ, bl.pos.dimid);
        }
    }

    //最后尝试放在上方
    if (mc.getBlock(bl.pos.x, bl.pos.y + 1, bl.pos.z, bl.pos.dimid).id === 0) {
        mc.setBlock(bl.pos.x, bl.pos.y + 1, bl.pos.z, bl.pos.dimid, "minecraft:redstone_block", 0);
        return mc.getBlock(bl.pos.x, bl.pos.y + 1, bl.pos.z, bl.pos.dimid);
    }

    return null;
}